package dfault;

import javax.swing.JFrame;

public class GameFrame extends JFrame {
	
	GameFrame(){
		this.add(new GamePanel()); //nothing to do with application opening
		this.setTitle("SnakeGame");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		this.pack(); //important as it spreads every JFrame update to the whole code
		this.setVisible(true);
		this.setLocationRelativeTo(null);
	}

}
