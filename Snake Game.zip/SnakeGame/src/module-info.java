/**
 * 
 */
/**
 * 
 */
module SnakeGame {
	requires java.desktop;
}